//
//  CustomShapePathsApp.swift
//  CustomShapePaths
//
//  Created by Amos from getstream.io on 2.2.2022.
//

import SwiftUI

@main
struct CustomShapePathsApp: App {
    var body: some Scene {
        WindowGroup {
            ChatBubbleWithTail()
        }
    }
}
