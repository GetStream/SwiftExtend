//
//  SVGToPath.swift
//  Created by Amos from getstream.io on 05/02/2022
//
// SVG to SwiftUI path
// https://quassum.github.io/SVG-to-SwiftUI/

import SwiftUI

struct SVGToPath: View {
    
    let chatIconColor = Color(#colorLiteral(red: 0.2997708321, green: 0.3221338987, blue: 0.3609524071, alpha: 1))
    
    var body: some View {
        ChatIcon()
            .frame(width: 114, height: 109)
            .foregroundColor(chatIconColor)
    }
}

struct ChatIcon: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let width = rect.size.width
        let height = rect.size.height
        path.move(to: CGPoint(x: 0.82614*width, y: 0.71021*height))
        path.addLine(to: CGPoint(x: 0.85121*width, y: 0.67264*height))
        path.addCurve(to: CGPoint(x: 0.91304*width, y: 0.47045*height), control1: CGPoint(x: 0.89051*width, y: 0.61376*height), control2: CGPoint(x: 0.91304*width, y: 0.54454*height))
        path.addCurve(to: CGPoint(x: 0.5*width, y: 0.08636*height), control1: CGPoint(x: 0.91304*width, y: 0.26161*height), control2: CGPoint(x: 0.73147*width, y: 0.08636*height))
        path.addCurve(to: CGPoint(x: 0.08696*width, y: 0.47045*height), control1: CGPoint(x: 0.26853*width, y: 0.08636*height), control2: CGPoint(x: 0.08696*width, y: 0.26161*height))
        path.addCurve(to: CGPoint(x: 0.5*width, y: 0.85454*height), control1: CGPoint(x: 0.08696*width, y: 0.6793*height), control2: CGPoint(x: 0.26853*width, y: 0.85454*height))
        path.addCurve(to: CGPoint(x: 0.5846*width, y: 0.84648*height), control1: CGPoint(x: 0.52903*width, y: 0.85454*height), control2: CGPoint(x: 0.55732*width, y: 0.85176*height))
        path.addLine(to: CGPoint(x: 0.59914*width, y: 0.84366*height))
        path.addLine(to: CGPoint(x: 0.89466*width, y: 0.89702*height))
        path.addLine(to: CGPoint(x: 0.82614*width, y: 0.71021*height))
        path.closeSubpath()
        path.move(to: CGPoint(x: 0.93772*width, y: 0.99243*height))
        path.addLine(to: CGPoint(x: 0.59965*width, y: 0.9314*height))
        path.addCurve(to: CGPoint(x: 0.5*width, y: 0.94091*height), control1: CGPoint(x: 0.56741*width, y: 0.93764*height), control2: CGPoint(x: 0.53409*width, y: 0.94091*height))
        path.addCurve(to: CGPoint(x: 0.00435*width, y: 0.47045*height), control1: CGPoint(x: 0.23191*width, y: 0.94091*height), control2: CGPoint(x: 0.00435*width, y: 0.73589*height))
        path.addCurve(to: CGPoint(x: 0.5*width, y: 0), control1: CGPoint(x: 0.00435*width, y: 0.20501*height), control2: CGPoint(x: 0.23191*width, y: 0))
        path.addCurve(to: CGPoint(x: 0.99565*width, y: 0.47045*height), control1: CGPoint(x: 0.76809*width, y: 0), control2: CGPoint(x: 0.99565*width, y: 0.20501*height))
        path.addCurve(to: CGPoint(x: 0.91896*width, y: 0.72206*height), control1: CGPoint(x: 0.99565*width, y: 0.56336*height), control2: CGPoint(x: 0.96728*width, y: 0.64965*height))
        path.addLine(to: CGPoint(x: 0.99231*width, y: 0.92205*height))
        path.addCurve(to: CGPoint(x: 0.98445*width, y: 0.97401*height), control1: CGPoint(x: 0.99875*width, y: 0.93959*height), control2: CGPoint(x: 0.99575*width, y: 0.95944*height))
        path.addCurve(to: CGPoint(x: 0.93772*width, y: 0.99243*height), control1: CGPoint(x: 0.97316*width, y: 0.98857*height), control2: CGPoint(x: 0.95531*width, y: 0.99561*height))
        path.closeSubpath()
        return path
    }
}

struct SVGToPath_Previews: PreviewProvider {
    static var previews: some View {
        SVGToPath()
            .preferredColorScheme(.dark)
    }
}
