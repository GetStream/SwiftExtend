//
//  ChatBubbleWithTail.swift

//  Draw a chat bubble in Sketch. Export to Kite as a shape layer. Generate Swift code code as a path and redraw it with the path tool in SwiftUI

//  Created by Amos from getstream.io on 2.2.2022.

import SwiftUI

struct ChatBubbleWithTail: View {
    
    let accentPrimary = Color(#colorLiteral(red: 0.03921568627, green: 0.5176470588, blue: 1, alpha: 1))
   
    var body: some View {
        // There are several ways to draw a path with SwiftUI. But let's use the one that accepts a closure.
        // 1.Create an empty path
        Path { path in // The closure accepts a single parameter called path.
            
            // 2. Move to a starting position
                path.move(to: CGPoint(x: 128.046494, y: 94))
            
            // 3. Adds a cubic Bézier curve to the path, with the specified end point and control points. Also, append a straight line segment from the current point to the specified point.
            path.addCurve(to: CGPoint(x: 5.788495, y: 94), control1: CGPoint(x: 87.293823, y: 94), control2: CGPoint(x: 46.541161, y: 94))
            path.addCurve(to: CGPoint(x: 0, y: 88.211502), control1: CGPoint(x: 2.591597, y: 94), control2: CGPoint(x: 0, y: 91.408401))
            path.addLine(to: CGPoint(x: 0, y: 5.788495))
            path.addCurve(to: CGPoint(x: 5.788495, y: 0), control1: CGPoint(x: 0, y: 2.591597), control2: CGPoint(x: 2.591597, y: -0))
            path.addLine(to: CGPoint(x: 131.551117, y: 0))
            path.addCurve(to: CGPoint(x: 137.339615, y: 5.788495), control1: CGPoint(x: 134.748016, y: -0), control2: CGPoint(x: 137.339615, y: 2.591597))
            path.addLine(to: CGPoint(x: 137.339615, y: 90.37278))
            path.addLine(to: CGPoint(x: 137.339615, y: 90.37278))
            path.addCurve(to: CGPoint(x: 140, y: 94), control1: CGPoint(x: 137.662308, y: 91.944199), control2: CGPoint(x: 138.549103, y: 93.153275))
            path.addCurve(to: CGPoint(x: 134.314621, y: 91.988411), control1: CGPoint(x: 138.22641, y: 94), control2: CGPoint(x: 136.331284, y: 93.329468))
            path.addCurve(to: CGPoint(x: 128.046494, y: 94), control1: CGPoint(x: 132.768066, y: 93.329468), control2: CGPoint(x: 130.678696, y: 94))
            
            // 4. Close and complete the current subpath (the shape we’ve drawn inside our path)
            path.closeSubpath()
            
            // 5. Move to the starting position
            path.move(to: CGPoint(x: 128.046494, y: 94))
        }
        // 6. Applying standard and shape modifiers
        .fill(accentPrimary)
        .offset(x: 125, y: 325)
    }
}

struct  ChatBubbleWithTail_Previews: PreviewProvider {
    static var previews: some View {
        ChatBubbleWithTail()
            .preferredColorScheme(.dark)
    }
}
