//
//  SFSymbolToPath.swift
//  Created by Amos from getstream.io on 13.12.2021.
//
//  Convert an SF Symbol to a SwiftUI path

import SwiftUI

struct SFSymbolToPath: View {
    
    var body: some View {
        Path{ path in
            path.move(to: CGPoint(x: 30.944824, y: 43.894531))
            path.addLine(to: CGPoint(x: 35.066895, y: 39.710938))
            path.addCurve(to: CGPoint(x: 30.421875, y: 38.634277), control1: CGPoint(x: 33.262207, y: 39.546875), control2: CGPoint(x: 31.713867, y: 39.187988))
            path.addCurve(to: CGPoint(x: 27.130371, y: 36.388672), control1: CGPoint(x: 29.129883, y: 38.080566), control2: CGPoint(x: 28.032715, y: 37.332031))
            path.addCurve(to: CGPoint(x: 23.777344, y: 30.882324), control1: CGPoint(x: 25.44873, y: 34.727539), control2: CGPoint(x: 24.331055, y: 32.89209))
            path.addCurve(to: CGPoint(x: 23.777344, y: 24.853027), control1: CGPoint(x: 23.223633, y: 28.872559), control2: CGPoint(x: 23.223633, y: 26.862793))
            path.addCurve(to: CGPoint(x: 27.099609, y: 19.34668), control1: CGPoint(x: 24.331055, y: 22.843262), control2: CGPoint(x: 25.438477, y: 21.007812))
            path.addLine(to: CGPoint(x: 36.697266, y: 9.810547))
            path.addCurve(to: CGPoint(x: 42.172852, y: 6.45752), control1: CGPoint(x: 38.337891, y: 8.128906), control2: CGPoint(x: 40.163086, y: 7.01123))
            path.addCurve(to: CGPoint(x: 48.202148, y: 6.45752), control1: CGPoint(x: 44.182617, y: 5.903809), control2: CGPoint(x: 46.192383, y: 5.903809))
            path.addCurve(to: CGPoint(x: 53.708496, y: 9.779785), control1: CGPoint(x: 50.211914, y: 7.01123), control2: CGPoint(x: 52.047363, y: 8.118652))
            path.addCurve(to: CGPoint(x: 57.061523, y: 15.316895), control1: CGPoint(x: 55.390137, y: 11.461426), control2: CGPoint(x: 56.507812, y: 13.307129))
            path.addCurve(to: CGPoint(x: 57.046143, y: 21.330811), control1: CGPoint(x: 57.615234, y: 17.32666), control2: CGPoint(x: 57.610107, y: 19.331299))
            path.addCurve(to: CGPoint(x: 53.708496, y: 26.821777), control1: CGPoint(x: 56.482178, y: 23.330322), control2: CGPoint(x: 55.369629, y: 25.160645))
            path.addLine(to: CGPoint(x: 48.41748, y: 32.143555))
            path.addCurve(to: CGPoint(x: 49.232666, y: 35.358154), control1: CGPoint(x: 48.827637, y: 33.148438), control2: CGPoint(x: 49.099365, y: 34.219971))
            path.addCurve(to: CGPoint(x: 49.125, y: 38.603516), control1: CGPoint(x: 49.365967, y: 36.496338), control2: CGPoint(x: 49.330078, y: 37.578125))
            path.addLine(to: CGPoint(x: 57.553711, y: 30.205566))
            path.addCurve(to: CGPoint(x: 62.275635, y: 22.39209), control1: CGPoint(x: 59.912109, y: 27.847168), control2: CGPoint(x: 61.486084, y: 25.242676))
            path.addCurve(to: CGPoint(x: 62.275635, y: 13.840332), control1: CGPoint(x: 63.065186, y: 19.541504), control2: CGPoint(x: 63.065186, y: 16.690918))
            path.addCurve(to: CGPoint(x: 57.522949, y: 5.965332), control1: CGPoint(x: 61.486084, y: 10.989746), control2: CGPoint(x: 59.901855, y: 8.364746))
            path.addCurve(to: CGPoint(x: 49.66333, y: 1.212646), control1: CGPoint(x: 55.144043, y: 3.586426), control2: CGPoint(x: 52.52417, y: 2.002197))
            path.addCurve(to: CGPoint(x: 41.111572, y: 1.228027), control1: CGPoint(x: 46.80249, y: 0.423096), control2: CGPoint(x: 43.951904, y: 0.428223))
            path.addCurve(to: CGPoint(x: 33.313477, y: 5.93457), control1: CGPoint(x: 38.27124, y: 2.027832), control2: CGPoint(x: 35.671875, y: 3.59668))
            path.addLine(to: CGPoint(x: 23.254395, y: 15.993652))
            path.addCurve(to: CGPoint(x: 18.563232, y: 23.807129), control1: CGPoint(x: 20.916504, y: 18.352051), control2: CGPoint(x: 19.352783, y: 20.956543))
            path.addCurve(to: CGPoint(x: 18.547852, y: 32.358887), control1: CGPoint(x: 17.773682, y: 26.657715), control2: CGPoint(x: 17.768555, y: 29.508301))
            path.addCurve(to: CGPoint(x: 23.285156, y: 40.233887), control1: CGPoint(x: 19.327148, y: 35.209473), control2: CGPoint(x: 20.90625, y: 37.834473))
            path.addCurve(to: CGPoint(x: 26.453613, y: 42.464111), control1: CGPoint(x: 24.1875, y: 41.095215), control2: CGPoint(x: 25.243652, y: 41.838623))
            path.addCurve(to: CGPoint(x: 30.944824, y: 43.894531), control1: CGPoint(x: 27.663574, y: 43.0896), control2: CGPoint(x: 29.160645, y: 43.566406))
            path.closeSubpath()
            path.move(to: CGPoint(x: 22.45459, y: 62.320801))
            path.addCurve(to: CGPoint(x: 30.268066, y: 57.583496), control1: CGPoint(x: 25.305176, y: 61.520996), control2: CGPoint(x: 27.909668, y: 59.941895))
            path.addLine(to: CGPoint(x: 40.296387, y: 47.555176))
            path.addCurve(to: CGPoint(x: 45.00293, y: 39.741699), control1: CGPoint(x: 42.634277, y: 45.196777), control2: CGPoint(x: 44.203125, y: 42.592285))
            path.addCurve(to: CGPoint(x: 45.018311, y: 31.174561), control1: CGPoint(x: 45.802734, y: 36.891113), control2: CGPoint(x: 45.807861, y: 34.0354))
            path.addCurve(to: CGPoint(x: 40.265625, y: 23.314941), control1: CGPoint(x: 44.22876, y: 28.313721), control2: CGPoint(x: 42.644531, y: 25.693848))
            path.addCurve(to: CGPoint(x: 37.112549, y: 21.053955), control1: CGPoint(x: 39.363281, y: 22.433105), control2: CGPoint(x: 38.312256, y: 21.679443))
            path.addCurve(to: CGPoint(x: 32.636719, y: 19.654297), control1: CGPoint(x: 35.912842, y: 20.428467), control2: CGPoint(x: 34.420898, y: 19.961914))
            path.addLine(to: CGPoint(x: 28.483887, y: 23.837891))
            path.addCurve(to: CGPoint(x: 33.128906, y: 24.914551), control1: CGPoint(x: 30.288574, y: 24.001953), control2: CGPoint(x: 31.836914, y: 24.36084))
            path.addCurve(to: CGPoint(x: 36.451172, y: 27.129395), control1: CGPoint(x: 34.420898, y: 25.468262), control2: CGPoint(x: 35.52832, y: 26.206543))
            path.addCurve(to: CGPoint(x: 39.773438, y: 32.651123), control1: CGPoint(x: 38.112305, y: 28.790527), control2: CGPoint(x: 39.219727, y: 30.631104))
            path.addCurve(to: CGPoint(x: 39.773438, y: 38.68042), control1: CGPoint(x: 40.327148, y: 34.671143), control2: CGPoint(x: 40.327148, y: 36.680908))
            path.addCurve(to: CGPoint(x: 36.451172, y: 44.171387), control1: CGPoint(x: 39.219727, y: 40.679932), control2: CGPoint(x: 38.112305, y: 42.510254))
            path.addLine(to: CGPoint(x: 26.884277, y: 53.738281))
            path.addCurve(to: CGPoint(x: 21.37793, y: 57.091309), control1: CGPoint(x: 25.223145, y: 55.419922), control2: CGPoint(x: 23.387695, y: 56.537598))
            path.addCurve(to: CGPoint(x: 15.348633, y: 57.075928), control1: CGPoint(x: 19.368164, y: 57.64502), control2: CGPoint(x: 17.358398, y: 57.639893))
            path.addCurve(to: CGPoint(x: 9.873047, y: 53.769043), control1: CGPoint(x: 13.338867, y: 56.511963), control2: CGPoint(x: 11.513672, y: 55.409668))
            path.addCurve(to: CGPoint(x: 6.52002, y: 48.231934), control1: CGPoint(x: 8.191406, y: 52.087402), control2: CGPoint(x: 7.07373, y: 50.241699))
            path.addCurve(to: CGPoint(x: 6.52002, y: 42.218018), control1: CGPoint(x: 5.966309, y: 46.222168), control2: CGPoint(x: 5.966309, y: 44.217529))
            path.addCurve(to: CGPoint(x: 9.842285, y: 36.727051), control1: CGPoint(x: 7.07373, y: 40.218506), control2: CGPoint(x: 8.181152, y: 38.388184))
            path.addLine(to: CGPoint(x: 15.133301, y: 31.374512))
            path.addCurve(to: CGPoint(x: 14.318115, y: 28.190674), control1: CGPoint(x: 14.723145, y: 30.390137), control2: CGPoint(x: 14.451416, y: 29.328857))
            path.addCurve(to: CGPoint(x: 14.425781, y: 24.914551), control1: CGPoint(x: 14.184814, y: 27.05249), control2: CGPoint(x: 14.220703, y: 25.960449))
            path.addLine(to: CGPoint(x: 5.99707, y: 33.343262))
            path.addCurve(to: CGPoint(x: 1.305908, y: 41.141357), control1: CGPoint(x: 3.65918, y: 35.70166), control2: CGPoint(x: 2.095459, y: 38.301025))
            path.addCurve(to: CGPoint(x: 1.290527, y: 49.693115), control1: CGPoint(x: 0.516357, y: 43.981689), control2: CGPoint(x: 0.51123, y: 46.832275))
            path.addCurve(to: CGPoint(x: 6.027832, y: 57.552734), control1: CGPoint(x: 2.069824, y: 52.553955), control2: CGPoint(x: 3.648926, y: 55.173828))
            path.addCurve(to: CGPoint(x: 13.887451, y: 62.336182), control1: CGPoint(x: 8.406738, y: 59.952148), control2: CGPoint(x: 11.026611, y: 61.546631))
            path.addCurve(to: CGPoint(x: 22.45459, y: 62.320801), control1: CGPoint(x: 16.748291, y: 63.125732), control2: CGPoint(x: 19.604004, y: 63.120605))
            path.closeSubpath()
            path.move(to: CGPoint(x: 22.45459, y: 62.320801))

        }
        .offset(x: 170, y: 350)
        //.trim(from: 1/2, to: 1)
    }
}

struct  SFSymbolToPath_Previews: PreviewProvider {
    static var previews: some View {
        SFSymbolToPath()
            .preferredColorScheme(.dark)
    }
}
